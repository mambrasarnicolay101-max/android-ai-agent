#!/usr/bin/env python3
"""
PROJECT OUROBOROS - EVOLUTION CORE
==================================
Orchestrator utama untuk siklus riset dan pengujian otomatis di VPS.
Skrip ini bertugas:
1. Menerima payload eksploitasi eksperimental (Python).
2. Mengeksekusinya terhadap Combat Arena (DVWA).
3. Menganalisis output, jika 'COMPROMISED', simpan ke arsip sukses (Memories).
4. Jika gagal, melaporkan 'FAILED' beserta stderr/stdout untuk iterasi agen.
"""

import os
import sys
import json
import importlib.util
import traceback
from datetime import datetime

MEMORIES_DIR = "/root/htb_sandbox/memories"
os.makedirs(MEMORIES_DIR, exist_ok=True)

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}")

def execute_payload(payload_file):
    """
    Mengeksekusi file Python eksternal (payload.py).
    File payload diwajibkan memiliki fungsi run_exploit(target_url) 
    yang me-return dict: {"status": "COMPROMISED"|"FAILED", "details": "..."}
    """
    log(f"[*] Menguji payload: {payload_file}")
    
    if not os.path.exists(payload_file):
        return {"status": "ERROR", "details": f"File {payload_file} tidak ditemukan."}
    
    try:
        # Load module secara dinamis
        spec = importlib.util.spec_from_file_location("dynamic_payload", payload_file)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        # Eksekusi fungsi utama
        target = "http://localhost:9090"
        log(f"[*] Mengeksekusi run_exploit({target})...")
        
        # Timeout tidak ditangani di sini, harus di payload itu sendiri
        result = module.run_exploit(target)
        return result
        
    except Exception as e:
        error_trace = traceback.format_exc()
        log(f"[!] Error saat eksekusi payload: {e}")
        return {"status": "ERROR", "details": error_trace}

def archive_memory(payload_file, result):
    """Menyimpan payload yang sukses ke arsip memori."""
    base_name = os.path.basename(payload_file)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    new_name = f"success_{ts}_{base_name}"
    dest_path = os.path.join(MEMORIES_DIR, new_name)
    
    with open(payload_file, 'r') as f_in, open(dest_path, 'w') as f_out:
        f_out.write(f'"""\nOUROBOROS ARCHIVE - SUCCESSFULLY EXPLOITED\nDetails: {json.dumps(result)}\n"""\n\n')
        f_out.write(f_in.read())
        
    log(f"[+] Payload berhasil! Diarsipkan ke: {dest_path}")
    return dest_path

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python ouroboros_core.py <payload_file.py>")
        sys.exit(1)
        
    payload_file = sys.argv[1]
    
    log("="*50)
    log("OUROBOROS CORE - COMMENCING EXPLOIT TEST")
    log("="*50)
    
    result = execute_payload(payload_file)
    
    log(f"[*] Hasil Eksekusi: {result.get('status')}")
    
    if result.get("status") == "COMPROMISED":
        archive_memory(payload_file, result)
        print("\n___OUROBOROS_SUCCESS___")
    else:
        print(f"\n___OUROBOROS_FAILED___\nDetails: {result.get('details')}")
        
    log("="*50)
