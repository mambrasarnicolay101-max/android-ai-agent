# Panduan Penggunaan Ouroboros Knowledge Base
# =============================================
# Semua pengetahuan di sini dikumpulkan dan disintesis oleh AI Agent (Project Omniscience)
# Terakhir diperbarui: 2026-05-31

# Struktur Direktori:
# knowledge_base/
# ├── literature/          → Riset akademik & teori (Markdown)
# ├── methods/             → Cheat sheet teknis & metodologi (Markdown)
# └── code_blueprints/     → Template payload Python siap pakai (Python)

# -------------------------------------------------------------------
# CARA MENGGUNAKAN BLUEPRINT DALAM OUROBOROS PIPELINE:
# -------------------------------------------------------------------
# 1. Salin blueprint yang relevan ke /root/htb_sandbox/payloads_queue/
# 2. Sesuaikan parameter target (endpoint, parameter name, dll)
# 3. Jalankan: python3 ouroboros_core.py <nama_blueprint.py>
# 4. Jika status COMPROMISED → otomatis diarsipkan ke /memories/

# -------------------------------------------------------------------
# DAFTAR BLUEPRINT TERSEDIA:
# -------------------------------------------------------------------
blueprints = {
    "blueprint_deserialization.py": {
        "vektor": "Insecure Deserialization",
        "sub-teknik": ["PHP Object Injection", "Java Gadget Chain (Commons Collections)"],
        "level": "Advanced",
        "delivery": ["Cookie", "POST body", "Binary HTTP body"]
    },
    "blueprint_ssrf_advanced.py": {
        "vektor": "SSRF",
        "sub-teknik": ["IPv6 Mapping Bypass", "DNS Rebinding", "Cloud Metadata Exfiltration",
                       "Redirect Abuse", "Octal/Decimal IP encoding"],
        "level": "Advanced",
        "delivery": ["GET parameter", "POST parameter"]
    },
    "blueprint_xxe_advanced.py": {
        "vektor": "XXE",
        "sub-teknik": ["Classic XXE", "WAF Padding Bypass (8KB+)", "PHP Filter Base64",
                       "OOB Exfiltration", "Content-Type Confusion", "SSRF via XXE"],
        "level": "Advanced",
        "delivery": ["POST XML body", "Content-Type Confusion"]
    },
}

# -------------------------------------------------------------------
# METODE RISET YANG DIGUNAKAN (Project Omniscience):
# -------------------------------------------------------------------
# - ouroboros_researcher: OSINT & web research (PortSwigger, HackTricks, GitHub)
# - research subagent: Akademik (arXiv, OpenAlex)
# - Main Agent synthesis: Code blueprint generation & weaponization
