# Autonomous Discovery: GraphQL Batching Bypass
**Date:** 2026-05-31T14:26:16.655364
**Source:** HackTheBox_Academy
**Weapon Used:** blueprint_graphql

## Context
AI Agent Noir berhasil menembus lab HackTheBox_Academy dengan memanfaatkan GraphQL Batching Bypass.
Data yang terekstrak: `HTB{graphql_singularity}`

## Vektor Serangan yang Berhasil
- query batching array injection
- introspection query with fragment bypass
