# WAF Evasion Techniques for SSRF and XXE (2024-2026)

This cheat sheet documents modern techniques used to bypass Web Application Firewalls (WAF) when exploiting Server-Side Request Forgery (SSRF) and XML External Entity (XXE) vulnerabilities.

## 1. SSRF WAF Evasion Techniques

Modern WAF evasion for SSRF relies on parser differentials, advanced encoding, and protocol manipulation.

### A. Parsing & Normalization Discrepancies
- **Parser Differentials**: Exploit differences in how WAFs parse a URL compared to the backend HTTP library. WAFs might block a specific hostname format, while the backend library standardizes it.
- **IPv4-Mapped IPv6 Addresses**: Bypass blacklists looking for IPv4 formats (e.g., `127.0.0.1`) by using IPv6 representations that resolve to localhost or internal network IPs:
  - `http://[::ffff:127.0.0.1]/`
  - `http://[:::::ffff:127.0.0.1]/`
  - `http://[0:0:0:0:0:ffff:127.0.0.1]/`
- **Multi-Layer Encoding**: Utilize URL, Double URL, Base64, Unicode, or Hex encoding. If a WAF fails to recursively decode, the backend might decode it successfully and access internal IPs (e.g., `169.254.169.254` for AWS metadata).

### B. Advanced Payload Obfuscation
- **Payload Padding & Fragmentation**: Inject a large amount of benign data (e.g., massive JSON arrays, long random strings) to exceed WAF buffer limits (usually 8KB-128KB). This hides the SSRF payload deep in the body, bypassing partial inspection.
- **Content-Type Confusion**: Send requests with non-standard or altered `Content-Type` headers to skip specific WAF rules while the backend application still processes the request based on content inference.

### C. Logic & Protocol Manipulation
- **DNS Rebinding**: A Time-Of-Check to Time-Of-Use (TOCTOU) attack. A domain initially resolves to a benign external IP during WAF inspection, but quickly switches its DNS record to an internal IP (like `127.0.0.1` or AWS metadata IP) when the backend resolves it.
- **Redirect Abuse**: Request a benign URL that the WAF permits, which then returns an HTTP 301/302 redirect pointing to an internal target. Backend HTTP clients often follow redirects by default.
- **CRLF & Protocol Smuggling**: Inject CRLF (`\r\n`) characters to smuggle headers or manipulate the protocol.

---

## 2. XXE WAF Evasion Techniques

WAF evasion for XXE exploits inspection limits, XML parser discrepancies, and architectural gaps.

### A. Inspection Limit & Buffer Exploitation
- **Payload Padding (The 8KB-128KB Limit)**: Similar to SSRF, WAFs often limit how much of a request body they inspect to preserve performance. By prepending the XML payload with massive amounts of benign XML comments, spaces, or attributes, the malicious DTD or entity declaration is pushed beyond the WAF's inspection buffer, reaching the backend parser undetected.

### B. Request Parsing Discrepancies
- **Extra Whitespace & Formatting**: "Lazy" WAFs often rely on rigid regex. Modifying the XML declaration spacing can bypass them while the backend parser still parses it:
  - `<? xml?>` or `<?xml version = "1.0"?>`
  - Using unusual whitespace characters (e.g., tabs, carriage returns) inside tags.
- **HTTP Parameter Pollution (HPP)**: Send multiple parameters with the same name. The WAF may only scan the first parameter (which is benign), while the backend application concatenates them or processes the last parameter containing the XXE payload.

### C. Advanced Encoding & Obfuscation
- **Multi-Layer / Nested Encoding**: Use URL, Unicode, Hex, or Base64 encoding. WAFs often fail to recursively decode the payload as deeply as the backend XML parser.
- **Character Entities**: Obfuscate restricted keywords (like `SYSTEM`, `file:///`, `http://`) using hexadecimal or decimal XML character references.

### D. Architectural & Protocol Bypasses
- **Out-of-Band (OOB) XXE & DTD Manipulation**: If local file retrieval (`file://`) is blocked, force the application to fetch an external malicious DTD hosted by the attacker. This shifts the attack from direct response to out-of-band data exfiltration.
- **Content-Type Confusion**: Change the `Content-Type` header to something like `text/plain` or `application/x-www-form-urlencoded`. If the WAF relies purely on headers to trigger XXE inspection, it might ignore the payload, but the backend application might still process it as XML due to loose typing.
- **Alternative Headers**: Inject XXE payloads into less commonly inspected HTTP headers (e.g., `X-Forwarded-For`, `User-Agent`) if the backend logs or processes them as XML.

---
*Generated via Cyber Intelligence Research (2024-2026).*
