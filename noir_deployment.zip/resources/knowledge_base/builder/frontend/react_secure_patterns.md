# Secure React/Next.js Frontend Patterns

## 1. Authentication State Management
Jangan simpan JWT (Access Token atau Refresh Token) di `localStorage` atau `sessionStorage` jika memungkinkan, untuk menghindari XSS.

**Best Practice:**
Simpan di `HttpOnly` secure cookies. Frontend tidak bisa membaca tokennya, tetapi browser akan otomatis mengirimkannya pada setiap request ke domain yang sama (atau subdomain yang diizinkan).

Jika harus menggunakan `localStorage` untuk SPA (Single Page Application) murni tanpa backend proxy:
- Simpan access token (short-lived, ex: 15 menit) di memory (React Context/Redux).
- Simpan refresh token di `HttpOnly` cookie.

```javascript
// Contoh membaca state auth dari Context (token di memory)
import { createContext, useContext, useState } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [accessToken, setAccessToken] = useState(null);

  // ... fungsi login, logout, refresh token
  
  return (
    <AuthContext.Provider value={{ user, accessToken, setUser, setAccessToken }}>
      {children}
    </AuthContext.Provider>
  );
};
```

## 2. Mencegah XSS (Cross-Site Scripting)

React secara default meng-escape nilai string pada JSX (contoh: `<div>{userInput}</div>`). Namun, kerentanan XSS masih bisa terjadi melalui `dangerouslySetInnerHTML`.

**JANGAN PERNAH** merender input user mentah menggunakan `dangerouslySetInnerHTML`.

```javascript
// BURUK
function BadComponent({ userHtml }) {
  return <div dangerouslySetInnerHTML={{ __html: userHtml }} />;
}

// BAIK (Gunakan library sanitasi seperti DOMPurify)
import DOMPurify from 'dompurify';

function GoodComponent({ userHtml }) {
  const cleanHtml = DOMPurify.sanitize(userHtml);
  return <div dangerouslySetInnerHTML={{ __html: cleanHtml }} />;
}
```

Hindari URL injection pada `href`:
```javascript
// BURUK - Attacker bisa mengirim "javascript:alert(1)"
<a href={userLink}>Klik di sini</a>

// BAIK - Validasi protokol
function SafeLink({ userLink }) {
  const isSafe = userLink.startsWith('http://') || userLink.startsWith('https://');
  return <a href={isSafe ? userLink : '#'}>Klik di sini</a>;
}
```

## 3. Komunikasi API (Axios Interceptors)

Gunakan Axios interceptors untuk otomatis menyisipkan token (jika di memory) dan menangani error secara terpusat (contoh: otomatis mencoba refresh token jika mendapat 401).

```javascript
import axios from 'axios';

const api = axios.create({
  baseURL: 'https://api.yourdomain.com',
  withCredentials: true, // PENTING jika menggunakan cookies
});

// Request Interceptor
api.interceptors.request.use(
  (config) => {
    // Jika menggunakan bearer token dari memory:
    // const token = getAccessToken();
    // if (token) {
    //   config.headers['Authorization'] = `Bearer ${token}`;
    // }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response Interceptor
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    // Jika 401 dan belum mencoba refresh
    if (error.response.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      try {
        // Panggil endpoint refresh token (yang akan membaca HttpOnly cookie)
        await api.post('/auth/refresh'); 
        
        // Coba ulang request asli
        return api(originalRequest);
      } catch (refreshError) {
        // Refresh token gagal/expired -> Redirect ke login
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }
    return Promise.reject(error);
  }
);

export default api;
```

## 4. Route Protection
Jangan hanya menyembunyikan elemen UI. Validasi akses di tingkat rute (meskipun frontend validation bisa di-bypass, ini penting untuk UX. Validasi sebenarnya HARUS terjadi di backend).

```javascript
// Contoh sederhana Protected Route di React Router v6
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './AuthContext';

const ProtectedRoute = ({ allowedRoles }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) return <div>Loading...</div>;

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <Outlet />;
};

// Penggunaan
// <Route element={<ProtectedRoute allowedRoles={['ADMIN']} />}>
//   <Route path="/admin" element={<AdminDashboard />} />
// </Route>
```
