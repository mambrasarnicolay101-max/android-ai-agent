# Secure DevOps & Deployment (Docker + CI/CD)

## 1. Dockerfile Best Practices

Membangun container image yang aman dan efisien.

```dockerfile
# 1. Gunakan base image yang spesifik dan slim/alpine
FROM python:3.11-slim-bookworm

# 2. Set environment variables (jangan simpan secret di ENV!)
ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1 \
    APP_HOME=/app

# 3. Buat non-root user secepat mungkin
# Menjalankan container sebagai root adalah resiko keamanan besar
RUN groupadd -r appuser && useradd -r -g appuser appuser

WORKDIR $APP_HOME

# 4. Install dependencies (layer caching)
# Copy requirements terlebih dahulu agar layer ini di-cache jika tidak ada perubahan package
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 5. Copy sisa kode aplikasi
COPY . .

# 6. Ganti ownership file ke non-root user
RUN chown -R appuser:appuser $APP_HOME

# 7. Ganti user aktif
USER appuser

# 8. Expose port (hanya untuk dokumentasi)
EXPOSE 8000

# 9. Healthcheck untuk orchestration (Docker Swarm/K8s)
HEALTHCHECK --interval=30s --timeout=3s \
  CMD curl -f http://localhost:8000/health || exit 1

# 10. Start command
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## 2. Docker Compose untuk Production
Jangan ekspos database port ke publik. Gunakan jaringan internal.

```yaml
version: '3.8'

services:
  web:
    build: .
    ports:
      - "8000:8000" # Ekspos aplikasi web
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/dbname
    depends_on:
      - db
    networks:
      - backend-network
    restart: unless-stopped

  db:
    image: postgres:15-alpine
    # JANGAN EKSPOS PORT DB KE HOST (e.g., ports: - "5432:5432")
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=dbname
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - backend-network
    restart: unless-stopped

volumes:
  postgres_data:

networks:
  backend-network:
    driver: bridge
```

## 3. GitHub Actions CI/CD Pipeline (Security Focused)

Contoh workflow untuk automatisasi testing, security scanning, dan build.

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]

jobs:
  test-and-scan:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    
    - name: Set up Python
      uses: actions/setup-python@v5
      with:
        python-version: '3.11'
        cache: 'pip'
        
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install pytest bandit safety
        
    # 1. SAST (Static Application Security Testing)
    - name: Run Bandit (Security Linter)
      run: bandit -r app/
      
    # 2. Dependency Vulnerability Check
    - name: Check Dependencies (Safety)
      run: safety check -r requirements.txt
      
    # 3. Unit Tests
    - name: Run Pytest
      run: pytest tests/

  build-and-push:
    needs: test-and-scan
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    
    # Setup Docker Buildx, Login to Registry, etc.
    # ...
    
    - name: Build and push Docker image
      uses: docker/build-push-action@v5
      with:
        context: .
        push: true
        tags: user/repo:latest
```
