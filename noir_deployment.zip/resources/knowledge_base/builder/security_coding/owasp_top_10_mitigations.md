# OWASP Top 10 Mitigations (Coding Standards)

## 1. Broken Access Control (BOLA/IDOR & Mass Assignment)
**Resiko:** User A bisa mengakses data User B, atau mengupdate field yang seharusnya tidak boleh diupdate (misal: role).

**Mitigasi:**
1. **Validasi Otorisasi di Tiap Endpoint:** Jangan pernah berasumsi bahwa UI sudah menyembunyikan tombolnya.
2. **Cek Kepemilikan (Ownership):** 
   ```python
   # Di backend (FastAPI contoh)
   def get_document(doc_id: int, current_user = Depends(get_current_user)):
       doc = db.query(Document).filter(Document.id == doc_id).first()
       # PENTING: Cek apakah user yang request adalah pemilik doc ini
       if doc.owner_id != current_user.id and not current_user.is_admin:
           raise HTTPException(status_code=403, detail="Forbidden")
       return doc
   ```
3. **Gunakan DTO/Pydantic Models secara ketat (Cegah Mass Assignment):**
   ```python
   # Hanya field ini yang diterima saat user update profile
   class UserUpdate(BaseModel):
       name: Optional[str] = None
       email: Optional[EmailStr] = None
       # JANGAN masukkan 'role' atau 'is_admin' di sini!
   ```

## 2. Cryptographic Failures (Data Exposure)
**Resiko:** Data sensitif bocor saat transit (MITM) atau saat didatabase (plaintext passwords).

**Mitigasi:**
1. **Enkripsi Transit:** Wajibkan HTTPS. HSTS (HTTP Strict Transport Security).
2. **Enkripsi At Rest (Passwords):** Gunakan bcrypt, Argon2, atau scrypt. Jangan pernah MD5/SHA1.
   ```python
   from passlib.context import CryptContext
   pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
   hash = pwd_context.hash("password_user") 
   ```
3. **Penyimpanan Secret:** Jangan hardcode secret/API keys di code. Gunakan Environment Variables (`.env`, AWS Secrets Manager).

## 3. Injection (SQLi, Command Injection)
**Resiko:** Attacker memasukkan payload ke dalam parameter input yang dieksekusi sebagai command atau query.

**Mitigasi:**
1. **SQL Injection:** Gunakan ORM (Object-Relational Mapping) seperti SQLAlchemy, Prisma, atau minimal Parameterized Queries. JANGAN pernah string concatenation.
   ```python
   # BURUK
   cursor.execute(f"SELECT * FROM users WHERE username = '{username}'") 
   # BAIK (Parameterized)
   cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
   # TERBAIK (ORM)
   db.query(User).filter(User.username == username).first()
   ```
2. **Command Injection:** Hindari penggunaan fungsi yang mengeksekusi shell (`os.system()`, `subprocess.run(shell=True)`). Jika harus, jangan berikan input user mentah.

## 4. Security Misconfiguration
**Resiko:** Debug mode nyala di production, default passwords, stack trace terlihat oleh user.

**Mitigasi:**
1. Matikan error reporting detail (stack trace) di production. Kirim exception ke tool monitoring (Sentry, dll), kembalikan response generik (misal: "Internal Server Error") ke user.
2. Hapus atau ganti password default komponen sistem.
3. Kunci cloud storage (S3 buckets) pastikan ACL tidak public.

## 5. Server-Side Request Forgery (SSRF)
**Resiko:** Attacker memaksa server melakukan request HTTP ke internal network (AWS Metadata, Redis lokal).

**Mitigasi:**
1. Validasi ketat URL yang dikirim user (Whitelist domain/IP yang diizinkan).
2. Gunakan network library yang tidak mengikuti redirects secara buta.
3. Deny-list IP internal (127.0.0.1, 169.254.169.254, 10.0.0.0/8).
   ```python
   import ipaddress
   import socket
   from urllib.parse import urlparse

   def is_safe_url(url_string):
       try:
           parsed = urlparse(url_string)
           ip = socket.gethostbyname(parsed.hostname)
           ip_obj = ipaddress.ip_address(ip)
           return not (ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local)
       except Exception:
           return False
   ```
