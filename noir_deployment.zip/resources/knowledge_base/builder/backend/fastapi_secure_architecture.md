# Secure Backend Architecture with FastAPI

## 1. Project Structure
```text
project_root/
├── app/
│   ├── api/
│   │   ├── dependencies.py  # Dependency injection (Auth, DB)
│   │   ├── endpoints/       # Route handlers
│   │   │   └── users.py
│   │   └── routes.py        # API router inclusion
│   ├── core/
│   │   ├── config.py        # Pydantic BaseSettings for env vars
│   │   └── security.py      # Password hashing, JWT creation
│   ├── models/              # SQLAlchemy / Tortoise ORM models
│   ├── schemas/             # Pydantic models for validation
│   ├── services/            # Business logic
│   └── main.py              # FastAPI app instance
├── tests/
├── .env
├── requirements.txt
└── Dockerfile
```

## 2. Authentication & Authorization (JWT)
Selalu gunakan `OAuth2PasswordBearer` dan validasi token dengan ketat.

```python
# app/core/security.py
from datetime import datetime, timedelta
from jose import jwt
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = "GANTI_DENGAN_ENV_VAR_YANG_KUAT"
ALGORITHM = "HS256"

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt
```

## 3. Dependency Injection for Security
Gunakan dependency injection untuk memvalidasi user pada setiap endpoint yang membutuhkan otentikasi.

```python
# app/api/dependencies.py
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from app.core.security import SECRET_KEY, ALGORITHM

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    # Fetch user from DB here
    # user = get_user(db, username=username)
    # if user is None:
    #     raise credentials_exception
    return username # return user object in practice
```

## 4. Rate Limiting (SlowApi)
Cegah brute force dan DoS dengan rate limiting.

```python
# app/main.py
from fastapi import FastAPI
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

limiter = Limiter(key_func=get_remote_address)
app = FastAPI()
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Usage in endpoints:
# @app.get("/login")
# @limiter.limit("5/minute")
# async def login(request: Request):
```

## 5. Middleware: CORS & Security Headers
```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-frontend-domain.com"], # JANGAN GUNAKAN "*" DI PRODUCTION
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)

@app.middleware("http")
async def add_security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response
```
