from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import json
import os

app = FastAPI()

# Allow CORS for React Dashboard
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

STATE_FILE = os.path.join(os.path.dirname(__file__), "singularity_state.json")

def read_state():
    if not os.path.exists(STATE_FILE):
        return {"ouroboros_logs": [], "singularity_feeds": [], "kb_stats": {}}
    with open(STATE_FILE, "r") as f:
        return json.load(f)

@app.get("/api/state")
def get_state():
    return read_state()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
