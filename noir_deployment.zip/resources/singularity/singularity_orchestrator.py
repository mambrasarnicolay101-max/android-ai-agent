import os
import subprocess
import time
import argparse

# -------------------------------------------------------------------------
# SINGULARITY: THE ORCHESTRATOR
# Skrip Utama Penghubung Sentinel, Engagement Engine, & Distiller
# -------------------------------------------------------------------------

def run_singularity_loop(continuous=False, interval_seconds=10):
    print("="*60)
    print("[INFINITY] PROJECT SINGULARITY - AUTONOMOUS REAL-WORLD LOOP STARTED")
    print("="*60)
    
    # Lokasi skrip
    base_dir = r"C:\Users\ASUS\.gemini\config\plugins\noir-sovereign\skills\autonomous-penetration\resources\singularity"
    sentinel_path = os.path.join(base_dir, "sentinel_external_intel.py")
    engagement_path = os.path.join(base_dir, "third_party_engagement.py")
    distiller_path = os.path.join(base_dir, "evolution_distiller.py")

    while True:
        print("\n[>>] Fase 1: Mengaktifkan Sentinel Intel (Recon)...")
        sentinel_result = subprocess.run(["python", sentinel_path], capture_output=True, text=True)
        
        target_json_str = sentinel_result.stdout.strip().split("\n")[-1]
        
        print("\n[>>] Fase 2: Menerjunkan Engagement Engine (Attack)...")
        engagement_result = subprocess.run(["python", engagement_path, target_json_str], capture_output=True, text=True)
        print(engagement_result.stdout)
        
        print("\n[>>] Fase 3: Mengaktifkan Evolution Distiller (Meta-Learning)...")
        subprocess.run(["python", distiller_path], capture_output=False)

        print("\n="*60)
        print(f"[INFINITY] SIKLUS COMPLETE - Menunggu siklus berikutnya dalam {interval_seconds} detik")
        print("="*60)

        if not continuous:
            break
            
        time.sleep(interval_seconds)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Singularity Autonomous Loop')
    parser.add_argument('--continuous', action='store_true', help='Jalankan dalam infinite loop (24/7)')
    parser.add_argument('--interval', type=int, default=15, help='Jeda waktu (detik) antar siklus')
    args = parser.parse_args()
    
    run_singularity_loop(continuous=args.continuous, interval_seconds=args.interval)
