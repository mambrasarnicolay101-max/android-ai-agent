import json
import os
import time

STATE_FILE = os.path.join(os.path.dirname(__file__), "singularity_state.json")

def init_state():
    if not os.path.exists(STATE_FILE):
        with open(STATE_FILE, 'w') as f:
            json.dump({"ouroboros_logs": [], "singularity_feeds": [], "kb_stats": {}}, f)

def log_ouroboros_action(message, log_type="info"):
    """Mencatat aksi engine eksploitasi (tipe: info, attack, warning, success, critical)"""
    init_state()
    try:
        with open(STATE_FILE, 'r') as f:
            state = json.load(f)
        
        # Batasi log maksimal 50 baris terakhir agar tidak membesar
        state["ouroboros_logs"].append({
            "time": time.strftime("%H:%M:%S"),
            "msg": message,
            "type": log_type
        })
        if len(state["ouroboros_logs"]) > 50:
            state["ouroboros_logs"] = state["ouroboros_logs"][-50:]
            
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=4)
    except Exception as e:
        print(f"[-] Error writing state: {e}")

def add_singularity_feed(target, vuln, status):
    """Menambahkan kejadian temuan autonomus Singularity"""
    init_state()
    try:
        with open(STATE_FILE, 'r') as f:
            state = json.load(f)
            
        # Hindari duplikat feed jika status belum berubah
        # Namun untuk simplicity, kita append ke awal list (terbaru di atas)
        state["singularity_feeds"].insert(0, {
            "target": target,
            "vuln": vuln,
            "status": status
        })
        if len(state["singularity_feeds"]) > 10:
            state["singularity_feeds"] = state["singularity_feeds"][:10]
            
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=4)
    except Exception as e:
        print(f"[-] Error writing state: {e}")

def update_kb_stats(stats_dict):
    init_state()
    try:
        with open(STATE_FILE, 'r') as f:
            state = json.load(f)
        state["kb_stats"] = stats_dict
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=4)
    except Exception as e:
        pass
